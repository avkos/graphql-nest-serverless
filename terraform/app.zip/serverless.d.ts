import { Context } from 'aws-lambda';
import { Response } from 'aws-serverless-express';
export declare function handler(event: any, context: Context): Promise<Response>;
