export declare class User {
    id: number;
    name: string;
    dob: Date;
    address: string;
    description: string;
    imageUrl: string;
    createdAt: Date;
    updatedAt: Date;
}
export declare class UserSearchResult {
    total: number;
    list: User[];
}
