/// <reference types="node" />
import { INestApplication } from '@nestjs/common';
import { Express } from 'express';
import { Server } from "http";
export declare function createApp(expressApp: Express): Promise<INestApplication>;
export declare function bootstrap(): Promise<Server>;
